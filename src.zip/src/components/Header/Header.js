import './Header.css';

const Header = () => {
    return <span className="header">🎬 Entertainment Hub 🎥</span>
}

export default Header;