const Search = () => {
    return (
        <div>
            <span className="pageTitle">Search</span>
            
        </div>
    )
}
export default Search;